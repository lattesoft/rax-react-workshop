export const setUser = (profile)=>{
    return {
        type: "SET_USER",
        profile
    }
}